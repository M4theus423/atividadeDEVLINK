// Complete o código:
let meuNome = "Ana";
let minhaIdade = 25;
let minhaCidade = "São Paulo";

// Exiba as informações usando template literals
console.log(`Meu nome é ${meuNome}, tenho ${minhaIdade} anos e moro em ${minhaCidade}.`);