// Complete o loop para contar de 1 a 10
for (let i = 1; i <= 10; i++) {
    console.log("Número:", i);
}

// Linha separadora
console.log("------------");

// Complete o loop para tabuada do 5
let numero = 5;
for (let i = 1; i <= 10; i++) {
    console.log(`${numero} x ${i} = ${numero * i}`);
}
