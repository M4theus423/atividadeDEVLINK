// Crie um array com 5 frutas
let frutas = ["maçã", "banana", "laranja", "uva", "manga"];

// Acesse e exiba o primeiro e último elemento
console.log("Primeira fruta:", frutas[0]);
console.log("Última fruta:", frutas[frutas.length - 1]);

// Exiba o tamanho do array
console.log("Total de frutas:", frutas.length);
